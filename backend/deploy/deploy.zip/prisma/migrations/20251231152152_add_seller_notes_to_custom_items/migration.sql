-- AlterTable
ALTER TABLE "custom_order_items" ADD COLUMN     "sellerNotes" TEXT;
