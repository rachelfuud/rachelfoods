-- DropIndex
DROP INDEX "delivery_agents_service_zip_codes_gin_idx";

-- DropIndex
DROP INDEX "ledger_entries_createdAt_desc_idx";
